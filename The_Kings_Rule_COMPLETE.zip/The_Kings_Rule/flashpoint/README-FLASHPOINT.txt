THE KING'S RULE — Flashpoint Archive submission package
========================================================

Two ready-to-upload curations, built to the layout Flashpoint's Curation Format
(https://flashpointarchive.org/datahub/Curation_Format) asks for. Each zip
contains exactly one curation folder, and that folder contains exactly the four
things Flashpoint wants: meta.yaml, logo.png, ss.png and a content/ folder.


1. WHAT IS IN THIS FOLDER
-------------------------
  The_Kings_Rule_Flash-flashpoint.zip     <- submit this one first
  The_Kings_Rule_HTML5-flashpoint.zip     <- optional second entry

  The_Kings_Rule_Flash/                   (the same folder, unpacked so you can
  The_Kings_Rule_HTML5/                    look inside or import it directly)


2. STRUCTURE (both curations)
-----------------------------
  The_Kings_Rule_Flash/
    meta.yaml
    logo.png            512 x 512, from the game's own title art + Gate Guard
    ss.png              1024 x 768, gameplay screenshot (chamber 1, key solved)
    content/
      localflash/
        kingsrule/
          kings_rule.swf

  The_Kings_Rule_HTML5/
    meta.yaml
    logo.png
    ss.png
    content/
      localflash/
        kingsrule/
          game.html
          assets/*.png   9 guard portraits used by the game

  Launch Command  (Flash) : http://localflash/kingsrule/kings_rule.swf
  Launch Command  (HTML5) : http://localflash/kingsrule/game.html

  Why localflash: Flashpoint reserves the localflash domain for offline media
  and personal projects, and tells curators to put the files in a folder named
  after the game. The game has no website of its own, so this is the correct
  form. If you would rather mirror the distribution URL, change the launch
  command to http://imortalimp.nl/kings_rule_cracktro/... and move the files
  into content/imortalimp.nl/kings_rule_cracktro/ — the Curation Notes already
  tell staff this is an option.


3. WHICH TO SUBMIT
------------------
Submit the FLASH one. Flashpoint is a Flash-first archive and the SWF is the
artifact that is actually at risk; it plays in Ruffle and in Flash Player 32
with no hacks, so Status is Playable.

Submit the HTML5 one as a SECOND, separate curation, not as an alternate
application (different technology = different entry). Two curations of the same
title can be read as a duplicate, so the Curation Notes in both files say
plainly that they are two builds of one game and that staff should add whichever
fits. If the reviewer objects, withdraw the HTML5 one — the Flash curation stands
on its own.


4. WHAT TO CHECK / CHANGE IN meta.yaml
--------------------------------------
Filled in and valid YAML (parses cleanly, all required fields present):

  Title              The King's Rule
  Alternate Titles   The Kings Rule; King's Rule
  Library            Arcade            (Games section, not Theatre)
  Developer          Arena.ai Agent Mode; River Lyle R.
  Publisher          (blank — nothing published it)
  Play Mode          Single Player
  Status             Playable
  Release Date       2026-11-14        (first release of this build)
  Version            3.0.0
  Languages          en
  Tags               Puzzle; Logic; Codebreaker; Mathematics
                     all four exist on datahub/Tags — do not add tags that are
                     not on that page, reviewers will ask for them to be removed
  Source             https://imortalimp.nl/kings_rule_cracktro.zip
  Platforms          Flash  /  HTML5
  Application Path   FPSoftware\Flash\flashplayer_32_sa.exe      (Flash)
                     FPSoftware\fpnavigator-portable\FPNavigator.exe (HTML5)
  Notes              what the game is, controls, that it is a 2026 remake
  Original Description  blank on purpose — there is no original store page to
                     quote, and staff reject made-up descriptions here
  Curation Notes     localflash rationale + the two-builds note

Things you may want to personalise before uploading: Developer (use your own
handle if you prefer), Release Date, and Version.


5. HOW TO ACTUALLY SUBMIT
-------------------------
  a) Join the Flashpoint Discord (https://discord.gg/kY8r2BbPQ9) — the
     submission system only accepts members.
  b) Search the collection first (https://flashpointproject.github.io/
     flashpoint-database/) for "King's Rule" to be sure nothing is already in.
  c) Optional but recommended: download Flashpoint Infinity (12+) and test it
     locally. Curate tab -> Import Folder -> point at The_Kings_Rule_Flash ->
     press Run. You should land on the copper-bar intro; press ENTER twice to
     reach chamber 1. The Logs tab should be clean.
  d) Upload the .zip at https://fpfss.unstable.life/web/submit — one zip per
     submission, in the same state as the folder you tested.
  e) Watch #fpfss-notifications. First approval gets you the Trial Curator role.


6. PRE-FLIGHT CHECKLIST (already verified here)
-----------------------------------------------
  [x] zip has a single root folder, nothing loose at the top level
  [x] meta.yaml parses as YAML, every required field non-empty
  [x] Launch Command starts with http:// (never https://)
  [x] Launch Command resolves to a file that exists inside content/
  [x] logo.png is PNG, square 512x512, from the game, no menu buttons, not the
      same image as the screenshot
  [x] ss.png is PNG, real gameplay (chamber 1 with the fourth key solved), full
      game window, no borders or black bars added
  [x] content/ holds only what the game needs — no README, no docs, no
      background.png (the HTML build draws its backdrop procedurally, so that
      file was dead weight and is not included)
  [x] no https:// or external URLs anywhere in the shipped game files
  [x] Flash build loads and plays from http://localflash/kingsrule/ (tested by
      serving content/ over http and loading the SWF through Ruffle)
  [x] HTML5 build plays the whole flow from http://localflash/kingsrule/
      game.html with its portraits loading from assets/


7. NOTES STAFF MAY ASK ABOUT
----------------------------
  * Keyboard: the game listens for keys on the SWF/document. In Flash Player 32
    the projector has focus immediately; in Ruffle click once inside the window
    first. The intro itself says "PRESS ENTER TO SKIP", so this is discoverable.
  * The King in chamber 9 denies every guess by design — the game has no victory
    screen. That is the original 1983 design, not a bug, and the Notes say so.
  * The game is a 2026 fan remake with original art, audio and code; no files
    were extracted from the 1983 Sunburst disk, so it is not an emulation or a
    ROM wrapper.
  * Answers can be four digits and the patterns go up to primes and compound
    "double then subtract" rules; that is this edition's harder difficulty, and
    it is described in the Notes.
